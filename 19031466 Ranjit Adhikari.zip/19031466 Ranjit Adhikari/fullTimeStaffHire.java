/**
 * Write a description of class FullTimeStaffHire here.
 *
 * @author (Ranjit)
 * @version (1.0)
 */
public class fullTimeStaffHire extends staffHire //creating a sub-class
 {
    private int salary ;
    private int workingHour;
    private String staffName;
    private String joiningDate;
    private String qualification;
    private String appointedBy;
    private boolean  joined;
    public fullTimeStaffHire(int vacancyNumber, String designation, String jobType,int salary, int workingHour)//creating constructor forthe class
    {
        super(vacancyNumber,designation,jobType);// invoking the super class by using  super keyword.
        this.salary=salary;
        this.workingHour=workingHour;
        staffName="";
        joiningDate="";
        qualification=""; 
        appointedBy="";
        joined= false;
    }
    //defining getter and setter method for each attributes
    public int getSalary(){
        return salary;
    }
    public int getWorkingHour(){
        return workingHour;
    }
    public String getStaffName(){
        return staffName;
    }
    public String getJoiningDate(){
        return joiningDate;
    }
    public String getQualification(){
        return qualification;
    }
    public String getAppointedBy(){
        return appointedBy;
    }
    public boolean getJoined(){
        return joined;
    }
    public void setSalary (int newSalary)// setter method for updating salary.
    {
        if(joined == false){
             this.salary= newSalary;
             System.out.println(" New salary is set to Rs. "+ newSalary+".");
        }else{
             System.out.println("The Salary of any staff cannot be changed as if the staff is already hired.");
             joined=true;
        }
    }
    public void setWorkingHour(int newWorkingHour) //setter method for updating workingHour
    { 
        if(joined==false){ //defining the Boolean value
             this.workingHour= newWorkingHour;
             System.out.println("New Working hour has been set to " +newWorkingHour+" Hours.");
        }else{
             System.out.println("Working Hour of any staff cannot be changed as if the staff has already been hired");
        }                     
    }
    public void hireFullTimeStaff(String staffName, String joiningDate, String qualification, String appointedBy) //creating constructor 
    {
        this.appointedBy=appointedBy;
        this.staffName=staffName;
        this.joiningDate=joiningDate;
        this.qualification=qualification;    
        this.staffName=staffName;
        if(joined== false){ //defining the Boolean value 
             System.out.println("The staff " + staffName +" is hired by "+ appointedBy + "." );
             joined=true ;
        } else{
             System.out.println("Sorry the staff has already been hired.");
             joined=true;
        }
    }
    public void displayInfo() //method to display information of this class
    {
        super.displayInfo();//calling the displayInfo method from StaffHire class
        if(joined==true)
            System.out.println("The Name of the Staff is: "+ getStaffName()+" .");
            System.out.println("The Salary of the Staff is: "+ getSalary()+" Ruppees.");
            System.out.println("The Working hours of the Staff is: "+ getWorkingHour()+" Hours.");
            System.out.println("The Joined Date of the Staff is: "+ getJoiningDate()+" .");
            System.out.println("The qualification of the Staff is: "+ getQualification()+ " .");
            System.out.println("The Staff is appointed by: "+ appointedBy+" .");
            System.out.println("........................................................");
    }
}
