/**
 * Write a description of class INGNepal here.
 *
 * @author (Ranjit Adhikari)
 * @version (a version number or a date)
 */
import javax.swing.*;
import java.awt.Color;
import java.awt.Font;


public class INGNepal{
    public static void main(String[]args){
        
                JFrame frame=new JFrame();
                frame.setSize(900,650);
		//title of JFrame
		frame.setTitle("Form 1");
		frame.setLayout(null);
		frame.setVisible(true);
		//for closing operation
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		//set background color to the frame
		Color c=new Color(127,255,212);
		frame.getContentPane().setBackground(c);
		
		
		// title
		JLabel title=new JLabel();
		title.setText("Staff Hire Form");
		
		//font for title
		Font f=new Font("Times New Roman",Font.PLAIN,40);
		title.setBounds(340,10,500,60);
		title.setFont(f);
		frame.add(title);
		
		
		//Button
		JButton b1=new JButton("Appoint Part Time Staff");
		b1.setEnabled(true);
		b1.setBounds(170,100,210,60);
		frame.add(b1);	
		
		JButton b2=new JButton("Appoint Full Time Staff");
		b2.setEnabled(true);
		b2.setBounds(500,100,210,60);
		frame.add(b2);
		
		JButton b3=new JButton("Hire Part Time Staff");
		b3.setEnabled(true);
		b3.setBounds(170,230,210,60);
		frame.add(b3);
		
		JButton b4=new JButton("Hire Full Time Staff");
		b4.setEnabled(true);
		b4.setBounds(500,230,210,60);
		frame.add(b4);
		
		JButton b5=new JButton("Terminate Part Time Staff");
		b5.setEnabled(true);
		b5.setBounds(170,360,210,60);
		frame.add(b5);
		
		JButton b6=new JButton("Display");
		b6.setEnabled(true);
		b6.setBounds(550,500,140,40);
		frame.add(b6);
		
		JButton b7=new JButton("Clear");
		b7.setEnabled(true);
		b7.setBounds(695,500,100,40);
		frame.add(b7);
		
        }
}