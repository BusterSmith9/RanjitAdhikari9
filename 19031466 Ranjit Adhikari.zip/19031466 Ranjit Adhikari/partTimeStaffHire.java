/**
 * Write a description of class PartTimeStaffHire here.
 *
 * @author (Ranjit)
 * @version (1.0)
 */
public class partTimeStaffHire extends staffHire //creating a subclass
{
     private int workingHour;
     private int wagesPerHour;
     private String staffName;
     private String joiningDate;
     private String qualification;
     private String appointedBy;
     private String shifts;
     private boolean joined;
     private boolean terminated;
     
     public partTimeStaffHire(int vacancyNumber, String designation, String jobType, int workingHour, int wagesPerHour, String shifts)
     { //creating constructor of this class
         super(vacancyNumber, designation, jobType);
         this.workingHour=workingHour;
         this.wagesPerHour=wagesPerHour;
         this.shifts=shifts;
         staffName="";
         joiningDate="";
         qualification="";
         appointedBy="";
         joined=false;
         terminated=false;
           
     }
     ////defining getter and setter method for each attributes
     public int getWorkingHour()
     {
         return workingHour;
     }
     public int getWagesPerHour()
     {
         return wagesPerHour;
     }
     public String getShift()
     {
         return shifts;
     }
     public String getStaffName()
     {
         return staffName;   
     }
     public String getJoiningDate()
     {
         return joiningDate;
     }
     public String getQualification()
     {
         return qualification;
     }
     public String getAppointedBy()
     {
         return appointedBy;
     }
     public boolean getJoined()
     {
         return joined;
     }
     public boolean getTerminated()
     {
         return terminated;
     }
     public void setShift(String newShift) //assigning uapdated value of shift
     {
         if(joined==false){ //providing boolean value of joined
            System.out.println("The shift has been changed from " +shifts+" to " +newShift+".");
            this.shifts=newShift;
         }else{
            System.out.println("The shift can't be changed as the staff has already been hired.");
         }
            }
     public void hirePartTimeStaff(String staffName,String joiningDate,String qualification,String appointedBy) //hire a part time staff creating a constructor
     {
         if(joined==true){ //providing boolean value of joined
            System.out.println("The staff has already been hired");
         }else{
            this.staffName=staffName;
            this.joiningDate=joiningDate;
            this.qualification=qualification;
            this.appointedBy=appointedBy;
            joined=true;
            terminated=false;
            System.out.println("The Staff "+ staffName+ " has been hired for a part time job."); 
         }
     }
     public void terminateStaff(String staffName,String joiningDate,String qualification,String appointedBy)
     { // method kick out or terminate staff from the job 
         if(terminated==true ){        
            System.out.println("No records of the staff can be found");
         }else{
            System.out.println(getStaffName()+" has been removed from the job");
            this.staffName=" ";
            this.joiningDate=" ";
            this.qualification=" ";
            this.appointedBy=" ";
            joined=false;
            terminated=true;
         }
     }
     public void displayPartTime(){ //method to display information of PartTimeStaffHire class
         super.displayInfo(); //calling displayInfo() method from StaffHire class
         if(joined=true){
            System.out.println("Vacancy Number: "+getVacancyNumber());
            System.out.println("Designation: " + getDesignation());
            System.out.println("Job Type: "+ getJobType());
            System.out.println("Staff Name: " +getStaffName());
            System.out.println("Wages per hour: " + getWagesPerHour());
            System.out.println("Working Hour: " + getWorkingHour());
            System.out.println("JoinedDate: " + getJoiningDate());
            System.out.println("Qualification: " + getQualification());
            System.out.println("Appointed By: " + getAppointedBy());
            System.out.println("Income per day: " + (wagesPerHour*workingHour));    
         }else{
            System.out.println("No staff has been hired yet for part time job");
            
         }
     }
}

