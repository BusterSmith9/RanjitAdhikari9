/**
 * Write a description of class StaffHire here.
 *
 * @author (Ranjit)
 * @version (1.0)
 */
public class staffHire
{
   private int vacancyNumber;     
   private String designation;
   private String jobType;
  public  staffHire(int vacancyNumber,String designation, String jobType){     //creating a constructor for the class
      this.vacancyNumber=vacancyNumber;
      this.designation=designation;
      this.jobType=jobType;
    
  }
   // getter and setter method for the variables to use them from the next clasees.
  public int getVacancyNumber(){
       return vacancyNumber;
  }
  public void setVacancyNumber(int VacancyNumber){
     this.vacancyNumber=VacancyNumber;
  }
  public String getDesignation(){
       return designation;
  }
  public void  setDesignation(String Designation){ //parameter Designation is used
       this.designation=Designation;
  }
  public String getJobType(){
       return jobType;
  }
  public void setJobType(String JobType){ //parameter JObType is used
     this.jobType=JobType;
  }
  public void displayInfo(){ //displaying the inormation
        System.out.println("............................................");
        System.out.println("Vacancy number : " + getVacancyNumber());
        System.out.println("Designatioin  :" + getDesignation());
        System.out.println("Job type  :" +getJobType() );
        System.out.println("............................................");
    }
}